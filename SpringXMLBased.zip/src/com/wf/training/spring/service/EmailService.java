package com.wf.training.spring.service;

import com.wf.training.spring.service.support.IFortuneService;

public class EmailService implements IMessageService {

	// will require instance of Fortune service (dependency)
	// we want it to be injected 
	private IFortuneService fortuneService;
	
	private String sender;
	
	// Constructor based DI
	/*public EmailService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	// setter based DI : Correct naming convention
	public void setFortuneService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	@Override
	public String sendMessage(String to, String message) {
		return "Email send to : " + to + "[ " + message + " ]" +
				"\nSend By : " + this.sender + 
				"\n" + this.fortuneService.dailyFortune();
				
	}

}
